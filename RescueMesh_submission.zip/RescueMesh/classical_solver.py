"""classical_solver.py - exact classical baseline (NO Qiskit in this file).

Idea of exhaustive search ("brute force"):
    1. List EVERY possible way to give each node one channel.
    2. Compute the total interference of each one.
    3. Keep the smallest. Because we looked at everything, it is guaranteed
       to be the global optimum.

With 5 nodes and 3 channels there are 3 * 3 * 3 * 3 * 3 = 3^5 = 243 options,
so this takes milliseconds. It stops being practical when the network grows
(for 30 nodes: 3^30 is about 2 * 10^14 options), which is exactly why people
study other optimization methods. We make no claim that QAOA beats this.
"""

from itertools import product

import config


def generate_assignments(nodes, channels):
    """Yield every channel assignment as a dict, e.g. {"A": 0, "B": 2, ...}.

    itertools.product(channels, repeat=5) produces every 5-long tuple of
    channels: (0,0,0,0,0), (0,0,0,0,1), ... (2,2,2,2,2).
    The k-th number in a tuple is the channel of the k-th node.
    By construction, each node gets exactly ONE channel.
    """
    for combo in product(channels, repeat=len(nodes)):
        yield dict(zip(nodes, combo))


def edge_interference(graph, assignment):
    """Interference paid by each edge, as {(u, v): cost}.

    An edge costs its weight if both ends use the same channel, else 0.
    """
    costs = {}
    for u, v, data in graph.edges(data=True):
        same_channel = assignment[u] == assignment[v]
        costs[(u, v)] = data["weight"] if same_channel else 0
    return costs


def total_interference(graph, assignment):
    """Total interference = sum of all edge costs."""
    return sum(edge_interference(graph, assignment).values())


def interference_from_binary_variables(graph, assignment, channels):
    """The SAME quantity, computed with the formula from Phase 1:

        sum over edges (i,j) of  w_ij * sum over channels c of  x(i,c) * x(j,c)

    where x(i,c) = 1 if node i uses channel c, else 0.
    Used only to double-check total_interference().
    """
    x = {(i, c): int(assignment[i] == c) for i in assignment for c in channels}
    total = 0
    for u, v, data in graph.edges(data=True):
        total += data["weight"] * sum(x[(u, c)] * x[(v, c)] for c in channels)
    return total


def solve_exhaustive(graph, nodes=None, channels=None):
    """Try all assignments and return the results.

    Returns a dict with:
        best_assignment   - one optimal assignment
        best_score        - the minimum interference
        all_optimal       - every assignment that reaches best_score
        all_scores        - list of (assignment, score) for all assignments
    """
    nodes = config.NODES if nodes is None else nodes
    channels = config.CHANNELS if channels is None else channels

    all_scores = []
    for assignment in generate_assignments(nodes, channels):
        all_scores.append((assignment, total_interference(graph, assignment)))

    best_score = min(score for _, score in all_scores)
    all_optimal = [a for a, score in all_scores if score == best_score]

    return {
        "best_assignment": all_optimal[0],
        "best_score": best_score,
        "all_optimal": all_optimal,
        "all_scores": all_scores,
    }


def validate_solution(graph, result, nodes=None, channels=None):
    """Run the Phase 2 checks. Returns a list of (check name, passed) pairs."""
    nodes = config.NODES if nodes is None else nodes
    channels = config.CHANNELS if channels is None else channels
    all_scores = result["all_scores"]
    checks = []

    # 1. We really enumerated 3^5 = 243 assignments, with no duplicates.
    expected = len(channels) ** len(nodes)
    unique = {tuple(sorted(a.items())) for a, _ in all_scores}
    checks.append((f"enumerated {expected} distinct assignments",
                   len(all_scores) == expected and len(unique) == expected))

    # 2. Every node gets exactly one valid channel in every assignment.
    checks.append(("every node has exactly one channel (all assignments)",
                   all(set(a) == set(nodes) and all(a[n] in channels for n in nodes)
                       for a, _ in all_scores)))

    # 3. Edge-by-edge scoring equals the x(i,c) formula from Phase 1.
    checks.append(("edge-based score == x(i,c) formula (all assignments)",
                   all(score == interference_from_binary_variables(graph, a, channels)
                       for a, score in all_scores)))

    # 4. No assignment beats the reported best score.
    best = result["best_score"]
    checks.append(("no assignment scores below the reported minimum",
                   all(score >= best for _, score in all_scores)))

    # 5. The reported best assignment really achieves that score.
    checks.append(("reported assignment achieves the reported minimum",
                   total_interference(graph, result["best_assignment"]) == best))

    # 6. Symmetry sanity check: channels are interchangeable, so every optimal
    #    assignment has (number of channels)! relabelled twins that are also
    #    optimal. The number of optima must therefore be a multiple of 3! = 6.
    factorial = 1
    for k in range(2, len(channels) + 1):
        factorial *= k
    checks.append((f"number of optimal assignments is a multiple of {factorial}",
                   len(result["all_optimal"]) % factorial == 0))
    return checks
