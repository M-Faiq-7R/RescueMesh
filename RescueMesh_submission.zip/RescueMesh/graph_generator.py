"""graph_generator.py - builds the weighted interference graph.

An edge between two nodes means: "their radio signals overlap".
The edge weight says how bad the overlap is. If the two nodes are put on
the SAME channel, that weight is paid as interference. If they are on
different channels, the edge costs nothing.
"""

import networkx as nx

import config


def build_interference_graph(nodes=None, edges=None):
    """Return an undirected weighted networkx Graph.

    nodes: list of node names   (defaults to config.NODES)
    edges: list of (u, v, weight) (defaults to config.EDGES)
    """
    nodes = config.NODES if nodes is None else nodes
    edges = config.EDGES if edges is None else edges

    graph = nx.Graph()                 # Graph = undirected: A-B is the same as B-A
    graph.add_nodes_from(nodes)
    for u, v, weight in edges:
        graph.add_edge(u, v, weight=weight)
    return graph
