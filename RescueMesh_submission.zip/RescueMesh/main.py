"""main.py - Phase 2 driver: build graph, run exhaustive search, validate."""

import csv
import json
import time

import numpy as np

import config
from classical_solver import edge_interference, solve_exhaustive, validate_solution
from evaluation import (method_stats, random_baseline, random_counts, summarize_samples,
                        validate_qubo, verify_results)
from graph_generator import build_interference_graph
from qubo_model import all_bitstrings, build_qubo, decode, qubo_energies, qubo_to_ising
from quantum_solver import QAOASolver, analyze_counts
from visualization import draw_architecture, draw_network, plot_phase5


def main():
    graph = build_interference_graph()
    print(f"Nodes: {list(graph.nodes)}")
    print(f"Channels: {config.CHANNELS}")
    print(f"Edges: {graph.number_of_edges()}, total weight if ALL edges clash: "
          f"{sum(d['weight'] for _, _, d in graph.edges(data=True))}")
    print("Network plot saved to", draw_network(graph))

    t0 = time.perf_counter()
    result = solve_exhaustive(graph)
    t_exhaustive = time.perf_counter() - t0
    scores = [s for _, s in result["all_scores"]]
    print(f"\nAssignments evaluated: {len(scores)}")
    print(f"Worst possible interference (everyone on one channel): {max(scores)}")
    print(f"Minimum interference (global optimum): {result['best_score']}")
    print(f"Number of optimal assignments (channel relabellings): {len(result['all_optimal'])}")

    best = result["best_assignment"]
    print("\nOne optimal assignment:")
    for node in config.NODES:
        print(f"  Node {node} ({config.NODE_ROLES[node]}): channel {best[node]}")

    print("\nInterference per edge under this assignment:")
    for (u, v), cost in edge_interference(graph, best).items():
        w = graph[u][v]["weight"]
        print(f"  {u}-{v} (weight {w}): channels {best[u]},{best[v]} -> cost {cost}")

    print("\nValidation checks:")
    checks = validate_solution(graph, result)
    for name, passed in checks:
        print(f"  [{'PASS' if passed else 'FAIL'}] {name}")
    assert all(p for _, p in checks), "A validation check failed!"

    # ---------------- Phase 3: QUBO ----------------
    print("\n=== Phase 3: QUBO model (P = %d) ===" % config.PENALTY)
    Q, offset = build_qubo(graph)
    h, J, const = qubo_to_ising(Q, offset)
    print(f"QUBO: {Q.shape[0]} variables, {int((Q != 0).sum())} non-zero Q entries, offset = {offset:.0f}")
    print(f"Ising: {len(h)} Z terms, {len(J)} ZZ terms, constant = {const:.2f}")
    qubo_checks = validate_qubo(graph, Q, offset, result)
    for name, passed, detail in qubo_checks:
        print(f"  [{'PASS' if passed else 'FAIL'}] {name}\n         {detail}")
    assert all(p for _, p, _ in qubo_checks), "A QUBO check failed!"

    # ---------------- Phase 4: QAOA (p = 1) ----------------
    print("\n=== Phase 4: QAOA, p = 1, Qiskit Aer state-vector simulator ===")
    SHOTS, SEED = 8192, 42
    solver = QAOASolver(Q, offset, h, J, const, p=1, shots=4096, seed=SEED)
    print(f"Circuit: {solver.circuit.num_qubits} qubits, depth after transpile = {solver.compiled.depth()}, "
          f"gates = {dict(solver.compiled.count_ops())}")
    t0 = time.perf_counter()
    params, mean_e = solver.optimize()
    t_opt_p1 = time.perf_counter() - t0
    evals_p1 = solver.n_evaluations
    print(f"Optimizer finished after {solver.n_evaluations} circuit evaluations (4096 shots each)")
    print(f"Best parameters: gamma = {params[0]:.4f}, beta = {params[1]:.4f}; sampled mean energy = {mean_e:.2f}")

    t0 = time.perf_counter()
    counts = solver.sample(params, shots=SHOTS)          # final sampling with the tuned parameters
    rows = analyze_counts(counts, solver.table)
    t_sample_p1 = time.perf_counter() - t0
    qaoa = summarize_samples(rows, graph, result["best_score"])
    rand = random_baseline(Q.shape[0], SHOTS, Q, offset, graph, result["best_score"], seed=SEED)

    def pct(a, b):
        return f"{100 * a / b:.2f}%"
    print(f"\nFinal sampling: {SHOTS} shots, {qaoa['distinct_bitstrings']} distinct bitstrings")
    print(f"  {'':34s}{'QAOA':>12s}{'random guess':>15s}")
    print(f"  {'valid assignments':34s}{pct(qaoa['valid_shots'], SHOTS):>12s}{pct(rand['valid_shots'], SHOTS):>15s}")
    print(f"  {'invalid assignments':34s}{pct(qaoa['invalid_shots'], SHOTS):>12s}{pct(rand['invalid_shots'], SHOTS):>15s}")
    print(f"  {'optimal assignments (score 0)':34s}{pct(qaoa['optimal_shots'], SHOTS):>12s}{pct(rand['optimal_shots'], SHOTS):>15s}")
    print(f"  {'best valid score found':34s}{str(qaoa['best_valid_score']):>12s}{str(rand['best_valid_score']):>15s}")
    print(f"\nExact classical optimum: {result['best_score']}")
    print(f"QAOA found the global optimum: {qaoa['found_optimum']} (gap = {qaoa['gap']})")
    if qaoa["best_valid"]:
        b = qaoa["best_valid"]
        print(f"Best valid QAOA allocation: {b['assignment']} (bitstring {b['bitstring']}, seen {b['count']}x)")

    # Exact probabilities from the state vector: DIAGNOSTIC ONLY (not available on real hardware).
    X = all_bitstrings(Q.shape[0]); E = qubo_energies(Q, offset, X)
    valid_mask = np.array([decode(x) is not None for x in X])
    probs = solver.exact_probabilities(params)
    print(f"Exact state-vector diagnostic: P(valid) = {probs[valid_mask].sum():.4f}, "
          f"P(optimal) = {probs[valid_mask & (E == result['best_score'])].sum():.5f}, <E> = {probs @ E:.2f} "
          f"(uniform guess: P(valid) = {valid_mask.mean():.4f}, P(optimal) = {(valid_mask & (E == 0)).mean():.5f})")

    print("\nTop 8 measured bitstrings (qubit 0 is the RIGHTMOST character):")
    for r in rows[:8]:
        tag = "valid  " if r["valid"] else "invalid"
        print(f"  {r['bitstring']}  count={r['count']:4d}  energy={r['energy']:6.1f}  {tag}")

    with open("results/qaoa_results.json", "w") as f:
        json.dump({"p": 1, "shots": SHOTS, "seed": SEED, "gamma": float(params[0]), "beta": float(params[1]),
                   "counts": counts,
                   "summary": {k: v for k, v in qaoa.items() if k != "best_valid"},
                   "random_baseline": {k: v for k, v in rand.items() if k != "best_valid"}}, f, indent=1)
    print("Saved results/qaoa_results.json")

    # ---------------- Phase 5: formal comparison ----------------
    print("\n=== Phase 5: QAOA p=1 vs QAOA p=2 vs random sampling vs exhaustive search ===")
    best_exact = result["best_score"]

    # Random baseline: same 8192-sample budget, timed like QAOA sampling (generate + decode).
    t0 = time.perf_counter()
    rand_counts = random_counts(Q.shape[0], SHOTS, SEED)
    rand_rows = analyze_counts(rand_counts, solver.table)
    t_sample_rand = time.perf_counter() - t0
    assert summarize_samples(rand_rows, graph, best_exact)["optimal_shots"] == rand["optimal_shots"]

    # Optional p = 2: same graph, QUBO and penalty. 4 parameters -> a grid is too big, so
    # run COBYLA from 8 starts (two built from the p=1 optimum, six random with fixed seed).
    g1, b1 = float(params[0]), float(params[1])
    rng = np.random.default_rng(SEED)
    starts = [[g1, 0.0, b1, 0.0],                       # layer 2 switched off = exactly the p=1 circuit
              [g1, g1, b1, b1]]
    starts += [[rng.uniform(0, 0.3), rng.uniform(0, 0.3), rng.uniform(0, np.pi), rng.uniform(0, np.pi)]
               for _ in range(6)]
    solver2 = QAOASolver(Q, offset, h, J, const, p=2, shots=4096, seed=SEED)
    t0 = time.perf_counter()
    params2, mean_e2 = solver2.optimize_from_starts(starts)
    t_opt_p2 = time.perf_counter() - t0
    t0 = time.perf_counter()
    counts2 = solver2.sample(params2, shots=SHOTS)
    rows2 = analyze_counts(counts2, solver2.table)
    t_sample_p2 = time.perf_counter() - t0
    print(f"p=2: {solver2.n_evaluations} circuit evaluations, {t_opt_p2:.1f}s; parameters "
          f"gamma={np.round(params2[:2], 4).tolist()}, beta={np.round(params2[2:], 4).tolist()}; "
          f"sampled mean energy {mean_e2:.2f} (p=1: {mean_e:.2f})")

    all_valid_scores = [s for _, s in result["all_scores"]]
    results = {
        "config": {"nodes": config.NODES, "channels": config.CHANNELS, "edges": config.EDGES,
                   "penalty": config.PENALTY, "shots": SHOTS, "seed": SEED,
                   "optimization_shots_per_evaluation": 4096},
        "exact": {"best_score": best_exact, "n_assignments": len(all_valid_scores),
                  "n_optimal_assignments": len(result["all_optimal"]),
                  "mean_interference_over_valid": sum(all_valid_scores) / len(all_valid_scores)},
        "methods": {
            "Random sampling": dict(method_stats(rand_rows, best_exact), counts=rand_counts),
            "QAOA p=1": dict(method_stats(rows, best_exact), counts=counts,
                             parameters={"gamma": [g1], "beta": [b1]},
                             optimization={"evaluations": evals_p1, "shots_per_evaluation": 4096,
                                           "final_sampled_mean_energy": mean_e}),
            "QAOA p=2": dict(method_stats(rows2, best_exact), counts=counts2,
                             parameters={"gamma": params2[:2].tolist(), "beta": params2[2:].tolist()},
                             optimization={"evaluations": solver2.n_evaluations, "shots_per_evaluation": 4096,
                                           "final_sampled_mean_energy": mean_e2}),
        },
        "runtime_seconds": {"exhaustive": t_exhaustive, "random_sampling": t_sample_rand,
                            "qaoa_p1_optimization": t_opt_p1, "qaoa_p1_sampling": t_sample_p1,
                            "qaoa_p2_optimization": t_opt_p2, "qaoa_p2_sampling": t_sample_p2},
    }

    # Comparison table (percentages are computed from the raw counts)
    exact_row = ["Exhaustive search", f"{len(all_valid_scores)} enumerated",
                 f"{len(all_valid_scores)} (100.00%)",
                 f"{len(result['all_optimal'])} ({100 * len(result['all_optimal']) / len(all_valid_scores):.2f}%)",
                 f"{len(result['all_optimal'])} of {len(result['all_optimal'])}", str(best_exact), "0",
                 f"{results['exact']['mean_interference_over_valid']:.2f}*", f"{t_exhaustive * 1000:.1f} ms"]
    table = [["Method", "Samples", "Valid (count, %)", "Optimal (count, %)", "Distinct optima",
              "Best valid", "Gap", "Mean energy", "Runtime"], exact_row]
    runtime_text = {"Random sampling": f"{t_sample_rand:.2f} s",
                    "QAOA p=1": f"{t_opt_p1:.0f} s opt + {t_sample_p1:.2f} s",
                    "QAOA p=2": f"{t_opt_p2:.0f} s opt + {t_sample_p2:.2f} s"}
    for name in ["Random sampling", "QAOA p=1", "QAOA p=2"]:
        m = results["methods"][name]
        table.append([name, str(m["shots"]), f"{m['valid_count']} ({m['valid_pct']:.2f}%)",
                      f"{m['optimal_count']} ({m['optimal_pct']:.2f}%)",
                      f"{m['distinct_optimal_assignments']} of {len(result['all_optimal'])}",
                      f"{m['best_valid_score']:g}", f"{m['gap']:g}", f"{m['mean_energy_all_samples']:.2f}",
                      runtime_text[name]])
    widths = [max(len(r[i]) for r in table) for i in range(len(table[0]))]
    for k, row in enumerate(table):
        print("  " + " | ".join(c.ljust(w) for c, w in zip(row, widths)))
        if k == 0:
            print("  " + "-+-".join("-" * w for w in widths))
    print("  * exhaustive row: mean interference over all 243 valid assignments (not comparable to the")
    print("    sampled rows, whose mean energy includes the penalty of invalid samples).")
    with open("results/comparison_table.csv", "w", newline="") as f:
        csv.writer(f).writerows(table)

    with open("results/phase5_results.json", "w") as f:
        json.dump(results, f, indent=1)

    checks5 = verify_results(results, graph)
    print("\nIndependent verification from raw counts:")
    for name, passed, detail in checks5:
        print(f"  [{'PASS' if passed else 'FAIL'}] {name}\n         {detail}")
    assert all(p for _, p, _ in checks5), "Phase 5 verification failed!"

    for fname in plot_phase5(results) + [draw_architecture()]:
        print("Saved", fname)


if __name__ == "__main__":
    main()
