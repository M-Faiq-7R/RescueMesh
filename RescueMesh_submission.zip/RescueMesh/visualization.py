"""visualization.py - Matplotlib/NetworkX plots.

Phase 2 only needs the network plot. More plots are added in Phase 6.
"""

import matplotlib
matplotlib.use("Agg")                  # draw to files, no window needed
import matplotlib.pyplot as plt
import networkx as nx

import config


def draw_network(graph, filename="results/network_graph.png"):
    """Draw the interference graph; thicker/darker edges = stronger interference."""
    pos = nx.spring_layout(graph, seed=42, weight=None)    # fixed seed -> same picture every run
    weights = [graph[u][v]["weight"] for u, v in graph.edges]

    fig, ax = plt.subplots(figsize=(8, 6))
    nx.draw_networkx_nodes(graph, pos, node_size=1400, node_color="#9ecae1",
                           edgecolors="black", ax=ax)
    nx.draw_networkx_labels(graph, pos, font_size=14, font_weight="bold", ax=ax)
    nx.draw_networkx_edges(graph, pos, width=[0.6 * w for w in weights],
                           edge_color=weights, edge_cmap=plt.cm.Reds,
                           edge_vmin=0, edge_vmax=max(weights), ax=ax)
    nx.draw_networkx_edge_labels(
        graph, pos, edge_labels={(u, v): graph[u][v]["weight"] for u, v in graph.edges},
        font_size=12, ax=ax)

    legend = "\n".join(f"{n}: {role}" for n, role in config.NODE_ROLES.items())
    ax.text(1.02, 0.5, legend, transform=ax.transAxes, va="center", fontsize=10,
            bbox=dict(boxstyle="round", facecolor="white", edgecolor="gray"))
    ax.set_title("RescueMesh: weighted interference graph\n"
                 "(edge label = interference cost if both nodes share a channel)")
    ax.axis("off")
    fig.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return filename


# ------------------------------------------------------------------ Phase 5
import json
import numpy as np

COLORS = {"Random sampling": "#9e9e9e", "QAOA p=1": "#1f77b4", "QAOA p=2": "#ff7f0e"}


def _style(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=0.3)
    ax.set_axisbelow(True)


def _bar_panel(ax, results, key_count, key_pct, ylabel, title):
    names = list(results["methods"])
    shots = results["config"]["shots"]
    vals = [results["methods"][n][key_pct] for n in names]
    bars = ax.bar(names, vals, color=[COLORS[n] for n in names], edgecolor="black")
    for bar, n in zip(bars, names):
        c = results["methods"][n][key_count]
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height(),
                f"{c} / {shots}\n({results['methods'][n][key_pct]:.2f}%)",
                ha="center", va="bottom", fontsize=10)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_ylim(0, max(vals) * 1.25)
    _style(ax)


def plot_phase5(results, outdir="results"):
    """Create the five Phase 5 figures from the saved results dict. Returns file names."""
    names = list(results["methods"])
    shots = results["config"]["shots"]
    files = []

    # 1. valid-solution rate
    fig, ax = plt.subplots(figsize=(7, 5))
    _bar_panel(ax, results, "valid_count", "valid_pct", "% of samples that are valid",
               f"Valid allocations (each node has exactly one channel)\n{shots} samples per method")
    f = f"{outdir}/fig1_valid_rates.png"; fig.savefig(f, dpi=150, bbox_inches="tight"); plt.close(fig); files.append(f)

    # 2. optimal-solution rate
    fig, ax = plt.subplots(figsize=(7, 5))
    _bar_panel(ax, results, "optimal_count", "optimal_pct", "% of samples that are optimal (interference 0)",
               f"Optimal allocations found\n{shots} samples per method (counts shown; they are small)")
    f = f"{outdir}/fig2_optimal_rates.png"; fig.savefig(f, dpi=150, bbox_inches="tight"); plt.close(fig); files.append(f)

    # 3. energy distributions
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
    max_e = max(float(k) for n in names for k in results["methods"][n]["energy_histogram"])
    bins = np.arange(0, max_e + 10, 10)
    for n in names:
        h = results["methods"][n]["energy_histogram"]
        e = np.array([float(k) for k in h]); w = np.array([h[k] for k in h]) / shots * 100
        ax1.hist(e, bins=bins, weights=w, histtype="step", linewidth=2, color=COLORS[n], label=n)
        ax1.axvline(results["methods"][n]["mean_energy_all_samples"], color=COLORS[n], ls=":", alpha=0.8)
    ax1.set_xlabel("QUBO energy of the measured bitstring (dotted = mean)")
    ax1.set_ylabel("% of samples (bins of width 10)")
    ax1.set_title("All samples: QAOA shifts probability toward lower energy")
    ax1.legend(); _style(ax1)
    scores = sorted({int(float(k)) for n in names for k in results["methods"][n]["valid_score_histogram"]})
    width = 0.8 / len(names)
    for i, n in enumerate(names):
        h = results["methods"][n]["valid_score_histogram"]
        ax2.bar(np.array(scores) + (i - (len(names) - 1) / 2) * width,
                [h.get(str(float(s)), h.get(str(s), 0)) for s in scores], width=width,
                color=COLORS[n], edgecolor="black", label=f"{n} ({results['methods'][n]['valid_count']} valid)")
    ax2.set_xlabel("Interference score of VALID samples (0 = optimal)")
    ax2.set_ylabel("Number of valid samples (raw counts)")
    ax2.set_title("Valid samples only")
    ax2.legend(); _style(ax2)
    f = f"{outdir}/fig3_energy_distribution.png"; fig.savefig(f, dpi=150, bbox_inches="tight"); plt.close(fig); files.append(f)

    # 4. classical optimum vs best QAOA result (+ mean quality of valid samples)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    labels = ["Exhaustive\n(exact)"] + names
    best = [results["exact"]["best_score"]] + [results["methods"][n]["best_valid_score"] for n in names]
    cols = ["#2ca02c"] + [COLORS[n] for n in names]
    ax1.bar(labels, best, color=cols, edgecolor="black")
    for i, v in enumerate(best):
        ax1.text(i, v + 0.05, f"{v:g}", ha="center", fontsize=11)
    ax1.axhline(results["exact"]["best_score"], color="green", ls="--", label="exact global minimum")
    ax1.set_ylim(0, 1); ax1.set_ylabel("Best valid interference score (lower = better)")
    ax1.set_title("Best valid result: every method reached the optimum 0\n(so this alone does not separate them)")
    ax1.legend(); _style(ax1)
    labels2 = ["All 243 valid\n(uniform)"] + names
    mean_valid = [results["exact"]["mean_interference_over_valid"]] + \
                 [results["methods"][n]["mean_interference_of_valid_samples"] for n in names]
    ax2.bar(labels2, mean_valid, color=["#2ca02c"] + [COLORS[n] for n in names], edgecolor="black")
    for i, v in enumerate(mean_valid):
        ax2.text(i, v + 0.1, f"{v:.2f}", ha="center", fontsize=11)
    ax2.set_ylabel("Mean interference of valid samples")
    ax2.set_title("Average quality of the valid samples")
    _style(ax2)
    f = f"{outdir}/fig4_best_vs_optimum.png"; fig.savefig(f, dpi=150, bbox_inches="tight"); plt.close(fig); files.append(f)

    # 5. runtime (log scale)
    rt = results["runtime_seconds"]
    labels = ["Exhaustive search\n(243 assignments)", f"Random sampling\n({shots} samples)",
              f"QAOA p=1\nfinal {shots} shots"]
    vals = [rt["exhaustive"], rt["random_sampling"], rt["qaoa_p1_sampling"]]
    cols = ["#2ca02c", COLORS["Random sampling"], COLORS["QAOA p=1"]]
    labels.append(f"QAOA p=1\nparameter optimization\n({results['methods']['QAOA p=1']['optimization']['evaluations']} circuit runs)")
    vals.append(rt["qaoa_p1_optimization"]); cols.append(COLORS["QAOA p=1"])
    if "QAOA p=2" in results["methods"]:
        labels.append(f"QAOA p=2\nparameter optimization\n({results['methods']['QAOA p=2']['optimization']['evaluations']} circuit runs)")
        vals.append(rt["qaoa_p2_optimization"]); cols.append(COLORS["QAOA p=2"])
    fig, ax = plt.subplots(figsize=(10, 5.5))
    bars = ax.bar(labels, vals, color=cols, edgecolor="black")
    ax.set_yscale("log")
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v * 1.15, f"{v:.3g} s", ha="center", fontsize=10)
    ax.set_ylabel("Wall-clock time in seconds (log scale)")
    ax.set_title("Runtime on one CPU. QAOA times are classical SIMULATION of the circuit,\nnot quantum-hardware time.")
    ax.tick_params(axis="x", labelsize=8); _style(ax)
    f = f"{outdir}/fig5_runtime.png"; fig.savefig(f, dpi=150, bbox_inches="tight"); plt.close(fig); files.append(f)
    return files

# ------------------------------------------------------- architecture diagram
def draw_architecture(filename="report/architecture_diagram.png"):
    """Draw the RescueMesh pipeline: classical (blue), quantum (purple) and the
    independent classical baseline (green). Pure Matplotlib, no data needed."""
    from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

    BLUE, PURPLE, GREEN, GREY = "#cfe2f3", "#e1d5f0", "#d5ecd4", "#eeeeee"
    EDGE = {BLUE: "#2a6099", PURPLE: "#6a3d9a", GREEN: "#2e7d32", GREY: "#666666"}
    fig, ax = plt.subplots(figsize=(16, 9.6))
    ax.set_xlim(0, 16); ax.set_ylim(0, 10); ax.axis("off")

    # lane backgrounds
    ax.add_patch(Rectangle((6.45, 3.75), 9.45, 3.0, color="#f3ecfa", zorder=0))
    ax.text(6.6, 6.55, "QUANTUM BRANCH  (Qiskit circuit, Aer simulator)", fontsize=10,
            color="#6a3d9a", fontweight="bold", va="top")
    ax.add_patch(Rectangle((0.2, 3.75), 6.0, 3.0, color="#eef7ee", zorder=0))
    ax.text(0.35, 6.55, "INDEPENDENT CLASSICAL BASELINE  (no Qiskit)", fontsize=10,
            color="#2e7d32", fontweight="bold", va="top")

    def box(x, y, w, h, title, body, color, number=None):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.04,rounding_size=0.12",
                                    facecolor=color, edgecolor=EDGE[color], linewidth=1.8, zorder=2))
        head = f"{number}. {title}" if number else title
        ax.text(x + w / 2, y + h - 0.2, head, ha="center", va="top", fontsize=10.5,
                fontweight="bold", zorder=3)
        ax.text(x + w / 2, y + h - 0.62, body, ha="center", va="top", fontsize=8.6, zorder=3,
                linespacing=1.35)

    def arrow(p, q, color="#333333", both=False, style="-|>", rad=0.0):
        ax.add_patch(FancyArrowPatch(p, q, arrowstyle="<|-|>" if both else style, mutation_scale=16,
                                     linewidth=1.8, color=color, zorder=1,
                                     connectionstyle=f"arc3,rad={rad}"))

    W, H = 2.9, 1.7
    # Row A: shared classical front end
    ya = 7.7
    xs = [0.3, 3.5, 6.7, 9.9, 13.1]
    box(xs[0], ya, W, H, "Network topology input", "5 nodes (A-E), 3 channels,\n7 interference edges\n(config.py)", BLUE, 1)
    box(xs[1], ya, W, H, "Weighted interference graph", "vertices = nodes,\nedge weight = severity\n(graph_generator.py)", BLUE, 2)
    box(xs[2], ya, W, H, "Binary decision variables", "x(i,c) = 1 if node i uses\nchannel c  ->  15 variables\n(qubo_model.py)", BLUE, 3)
    box(xs[3], ya, W, H, "QUBO construction", "interference + P*(exactly-one)^2\nP = 15, 51 non-zero Q entries\n(qubo_model.py)", BLUE, 4)
    box(xs[4], ya, W, H, "Ising Hamiltonian", "x = (1 - z)/2  ->  h, J, const\n15 Z terms, 36 ZZ terms\n(qubo_model.py)", BLUE, 5)
    for a, b in zip(xs[:-1], xs[1:]):
        arrow((a + W + 0.04, ya + H / 2), (b - 0.04, ya + H / 2))

    # Row B: baseline (left) and quantum (right)
    yb = 4.05
    box(0.5, yb, 2.7, 1.9, "Exhaustive search", "enumerate all 3^5 = 243\nassignments, score each\n(classical_solver.py)", GREEN, 8)
    box(3.45, yb, 2.6, 1.9, "Exact optimum", "minimum interference = 0\n6 optimal assignments\n+ validation checks", GREEN)
    arrow((3.45 + 0.1, ya - 0.04), (1.85, yb + 1.9 + 0.04), color="#2e7d32", rad=0.0)   # graph -> exhaustive
    arrow((3.2 + 0.04, yb + 0.95), (3.45 - 0.04, yb + 0.95), color="#2e7d32")

    box(6.7, yb, 2.8, 1.9, "QAOA quantum circuit", "H on all qubits, then p layers:\ncost RZ/RZZ(gamma), mixer RX(beta)\n15 qubits, measure all\n(quantum_solver.py)", PURPLE, 6)
    box(9.85, yb, 2.8, 1.9, "Measurement + decoding", "8,192 shots -> bitstrings\nqubit 0 = rightmost character\n-> node-channel allocation,\nvalid / invalid split", PURPLE, 7)
    box(13.0, yb, 2.8, 1.9, "Candidate allocations", "QUBO energy per candidate\nbest valid allocation\nfrequency of valid / optimal", PURPLE)
    arrow((14.55, ya - 0.04), (14.55, 6.0 + 0.55), color="#6a3d9a")                  # Ising -> down
    ax.plot([14.55, 8.1], [6.0 + 0.55, 6.0 + 0.55], color="#6a3d9a", lw=1.8, zorder=1)
    arrow((8.1, 6.0 + 0.55), (8.1, yb + 1.9 + 0.04), color="#6a3d9a")                # -> circuit
    arrow((9.5 + 0.04, yb + 0.95), (9.85 - 0.04, yb + 0.95), color="#6a3d9a")
    arrow((12.65 + 0.04, yb + 0.95), (13.0 - 0.04, yb + 0.95), color="#6a3d9a")

    # hybrid loop
    box(6.7, 2.1, 2.8, 1.35, "Classical optimizer", "grid search + COBYLA tune\ngamma, beta from sampled energy", BLUE)
    arrow((8.1, yb - 0.04), (8.1, 3.45 + 0.04), both=True, color="#444444")
    ax.text(8.25, 3.77, "parameters  <->  mean energy", fontsize=8, color="#444444", va="center")

    # Row C: random baseline + comparison
    box(9.85, 2.1, 2.8, 1.35, "Random-sampling baseline", "8,192 random bitstrings,\nscored like QAOA output", GREY)
    box(0.5, 0.25, 15.3, 1.5, "9. Results comparison and visualization",
        "exact optimum vs QAOA p=1 / p=2 vs random sampling: valid and optimal counts, mean energy, gap, runtime\n"
        "independent verification from raw bitstrings  |  Matplotlib figures  (evaluation.py, visualization.py, main.py)", BLUE)
    arrow((4.75, yb - 0.04), (4.75, 1.75 + 0.04), color="#2e7d32")                    # exact optimum -> compare
    arrow((14.4, yb - 0.04), (14.4, 1.75 + 0.04), color="#6a3d9a")                    # candidates -> compare
    arrow((11.25, 2.1 - 0.04), (11.25, 1.75 + 0.04), color="#666666")                  # random -> compare

    # legend
    for i, (c, t) in enumerate([(BLUE, "Classical"), (PURPLE, "Quantum (simulated)"),
                                (GREEN, "Independent exact baseline"), (GREY, "Reference baseline")]):
        ax.add_patch(Rectangle((0.3 + i * 3.6, 9.55), 0.3, 0.25, facecolor=c, edgecolor=EDGE[c]))
        ax.text(0.7 + i * 3.6, 9.675, t, va="center", fontsize=9)
    ax.set_title("RescueMesh architecture: quantum-assisted channel allocation vs exact classical baseline",
                 fontsize=13, fontweight="bold", y=0.985)
    fig.savefig(filename, dpi=170, bbox_inches="tight")
    plt.close(fig)
    return filename
